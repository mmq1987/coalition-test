<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <div>
                        <button id="btn-add" name="btn-add" class="btn btn-primary btn-xs">Add New Product</button>
                    </div>
                    
                    <div>
                        <?php if(!empty($products)): ?>
                        <table class="table table-inverse">
                            <thead>
                                <tr>
                                    <th>Product name</th>
                                    <th>Quantity in stock</th>
                                    <th>Price per item</th>
                                    <th>Datetime submitted</th>
                                    <th>Total value number</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <?php
                            $total_amount = 0;
                            ?>
                            <tbody id="product-list" name="product-list">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $amount =  $product->quantity * $product->price ?>
                                <tr id="product<?php echo e($product->id); ?>">
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td><?php echo '$'.number_format($product->price,2); ?></td>
                                    <td><?php echo date('m-d-Y',$product->date); ?></td>
                                    <td><?php echo '$'.number_format($amount,2); ?></td>
                                    <td>
                                        <button class="btn btn-info open-modal" value="<?php echo e($product->id); ?>">Edit
                                        </button>
                                        <button class="btn btn-danger delete-link" value="<?php echo e($product->id); ?>">Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php 
                                $total_amount = $total_amount+$amount;
                                
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" style="text-align: right">
                                        <strong>Total: </strong>
                                    </td>
                                    <td colspan="2" style="text-align: left"><strong><?php echo '$'.number_format($total_amount,2); ?></strong></td>
                                </tr>
                                <input type="hidden" id="total_val" value="<?php echo $total_amount; ?>" />
                            </tfoot>
                        </table>
                        <?php endif; ?>
                        <div id="linkEditorModal" style="display: none;" aria-hidden="true">
                            <h4 class="modal-title" id="linkEditorModalLabel">Add Product</h4>
                            <form id="modalFormData" name="modalFormData" class="form-horizontal" novalidate="">

                                <div class="form-group">
                                    <label for="inputLink" class="col-sm-5 control-label">Product Name</label>
                                    <div class="col-sm-7">
                                        <input type="text" class="form-control" id="name" name="name"
                                               placeholder="Product Name" value="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputLink" class="col-sm-5 control-label">Product Quantity</label>
                                    <div class="col-sm-7">
                                        <input type="text" class="form-control" id="quantity" name="quantity"
                                               placeholder="Product Quantity" value="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputLink" class="col-sm-5 control-label">Product Price</label>
                                    <div class="col-sm-7">
                                        <input type="text" class="form-control" id="price" name="price"
                                               placeholder="Product Price" value="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" class="col-sm-12 btn btn-primary" id="btn-save" value="add">Save Product</button>
                                    <input type="hidden" name="id" id="id" />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('.date_submitted').datepicker({
        format: 'dd-mm-yyyy'
    });
    jQuery(document).ready(function ($) {
        ////----- Open the modal to CREATE a link -----////
        jQuery('#btn-add').click(function () {
            jQuery('#btn-save').val("add");
            jQuery('#modalFormData').trigger("reset");
            jQuery('#linkEditorModal').modal();
        });

        ////----- Open the modal to UPDATE a link -----////
        jQuery('body').on('click', '.open-modal', function () {
            var id = $(this).val();
            $.get('product/' + id, function (data) {
                jQuery('#id').val(id);
                jQuery('#name').val(data.name);
                jQuery('#quantity').val(data.quantity);
                jQuery('#price').val(data.price);
                jQuery('#btn-save').val("update");
                jQuery('#linkEditorModal').modal();
            })
        });

        // Clicking the save button on the open modal for both CREATE and UPDATE
        $("#btn-save").click(function (e) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                }
            });
            e.preventDefault();
            var formData = {
                name: jQuery('#name').val(),
                quantity: jQuery('#quantity').val(),
                price: jQuery('#price').val(),
                id: jQuery('#price').val(),
            };
            var state = jQuery('#btn-save').val();
            var type = "POST";
            var id = jQuery('#id').val();
            var ajaxurl = 'addProduct';
            if (state == "update") {
                type = "PUT";
                ajaxurl = 'updateProduct/' + id;
            }
            $.ajax({
                type: type,
                url: ajaxurl,
                data: formData,
                dataType: 'json',
                success: function (data) {
                    var link = '<tr id="product' + data.id + '"><td>' + data.name + '</td><td>' + data.quantity + '</td><td>' + data.price + '</td><td>' + data.date + '</td><td>' + data.total + '</td>';
                    link += '<td><button class="btn btn-info open-modal" value="' + data.id + '">Edit</button>&nbsp;';
                    link += '<button class="btn btn-danger delete-link" value="' + data.id + '">Delete</button></td></tr>';
                    if (state == "add") {
                        jQuery('#product-list').append(link);
                    } else {
                        $("#product" + id).replaceWith(link);
                    }
                    jQuery('#modalFormData').trigger("reset");
                    $.modal.close();
                },
                error: function (data) {
                    console.log('Error:', data);
                }
            });
        });

        ////----- DELETE a link and remove from the page -----////
        jQuery('.delete-link').click(function () {
            var id = $(this).val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "DELETE",
                url: 'deleteProdct/' + id,
                success: function (data) {
                    console.log(data);
                    $("#product" + id).remove();
                },
                error: function (data) {
                    console.log('Error:', data);
                }
            });
        });
    });
</script>
<style>
    #linkEditorModal{
        overflow: visible !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/coalition-test/resources/views/product.blade.php ENDPATH**/ ?>